import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './InputForm.css';

const InputForm = ({ onFormSubmit, history }) => {
  const [full_name, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [roles, setRole] = useState('');
  const [fullNameError, setFullNameError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [rolesError, setRolesError] = useState('');
  const navigate = useNavigate();

  const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFullNameError('');
    setEmailError('');
    setRolesError('');

    try {
      await axios.post(`${apiUrl}/users`, { full_name, email, roles });
      navigate('/users');
    } catch (error) {
      if (error.response && error.response.data) {
        const { message } = error.response.data;
        const errorsArray = message.split(', ');
        errorsArray.forEach(errorMsg => {
          if (errorMsg.includes('full_name')) {
            setFullNameError(errorMsg);
          } else if (errorMsg.includes('email')) {
            setEmailError(errorMsg);
          } else if (errorMsg.includes('roles')) {
            setRolesError(errorMsg);
          }
        });
      }
    }
  };

  return (
    <div className="form-container">
      <h2>User Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <input
            type="text"
            className="input-field"
            placeholder="Full Name"
            value={full_name}
            onChange={(e) => setFullName(e.target.value)}
          />
          {fullNameError && <div className="error-message">{fullNameError}</div>}
        </div>
        <div className="form-group">
          <input
            type="email"
            className="input-field"
            placeholder="Email Address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          {emailError && <div className="error-message">{emailError}</div>}
        </div>
        <div className="form-group">
          <select
            className="select-field"
            value={roles}
            onChange={(e) => setRole(e.target.value)}
          >
            <option value="">Select Role</option>
            <option value="1">Author</option>
            <option value="2">Editor</option>
            <option value="3">Subscriber</option>
            <option value="4">Administrator</option>
          </select>
          {rolesError && <div className="error-message">{rolesError}</div>}
        </div>
        <button type="submit" className="submit-button">
          Submit
        </button>
      </form>
    </div>
  );
};

export default InputForm;
