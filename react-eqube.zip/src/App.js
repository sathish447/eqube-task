// app.js

import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; // Import Routes instead of Switch
import InputForm from './InputForm';
import UserList from './UserList';

const App = () => {
  return (
    <Router>
      <Routes> {/* Replace Switch with Routes */}
        <Route exact path="/" element={<InputForm />} />
        <Route path="/users" element={<UserList />} />
      </Routes> {/* Replace Switch with Routes */}
    </Router>
  );
};

export default App;
