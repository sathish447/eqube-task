############################
Steps to Configure
############################

React

    1. npm install
    2. npm start