<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

use DB;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            'Author',
            'Editor',
            'Subscriber',
            'Administrator'
        ];

        foreach ($items as $item) {
            \App\Models\Role::create([
                'name' => $item,
            ]);
        }
    }
}
