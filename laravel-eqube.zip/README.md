############################
Steps to Configure
############################

Laravel 
-------

	1. composer update
	2. Copy  ".env.example" to ".env"
	3. Create a new database, for configuring DB run command "php artisan set:credentials" 
	4. "php artisan key:generate"
	5. "php artisan migrate"
	6. "php artisan db:seed --class=RoleSeeder"
	7. "php artisan db:seed"