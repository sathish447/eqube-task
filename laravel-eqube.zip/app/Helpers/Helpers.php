<?php


if (!function_exists('apiResponse')) {
  
    function apiResponse($data)
    {
        $httpCode = $data["httpCode"] ?? 200;

        $response = [
            'error_code' => ($data["response"] ?? "success") === "error" ? 1 : 0,
            'message' => $data["message"] ?? ($httpCode === 200 ? "Success" : "An error occurred."),
        ];

        if ($response["error_code"] === 0 && isset($data["data"])) {
            $response["data"] = $data["data"];
        }

        return response()->json($response, $httpCode)
            ->header('X-Frame-Options', 'SAMEORIGIN')
            ->header('Strict-Transport-Security', 'max-age=63072000; includeSubDomains')
            ->header('X-Content-Type-Options', 'nosniff')
            ->header('Content-Type', 'application/json')
            ->header('Referrer-Policy', 'origin-when-cross-origin')
            ->header('X-XSS-Protection', '1; mode=block')
            ->header('Access-Control-Allow-Origin', '*')
            ->header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    }

}