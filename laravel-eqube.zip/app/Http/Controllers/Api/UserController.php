<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Http\Requests\UserRequest;

use App\Models\User;
use App\Models\Role;

class UserController extends Controller
{
    public function store(UserRequest $request)
	{
	    $user = User::create($request->validated());
	    $user->roles()->attach($request->input('roles'));
	    return response()->json($user, 201);
	}

	public function indexByRole()
	{
	    $users = User::with('roles:name')->get();
	    
	    return response()->json($users, 200);
	}
}
